package com.mycompany.digipay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
